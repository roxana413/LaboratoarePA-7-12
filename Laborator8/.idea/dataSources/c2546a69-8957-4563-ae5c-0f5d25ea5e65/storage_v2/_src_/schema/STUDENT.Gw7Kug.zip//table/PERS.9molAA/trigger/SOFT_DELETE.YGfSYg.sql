create trigger SOFT_DELETE
    before delete
    on PERS
    for each row
DECLARE 
id_2 INT;
BEGIN

  INSERT INTO persDeleted( id ,nume, prenume, telefon, deleted, created_at, updated_at)
  VALUES( old.id ,old.nume, old.prenume, old.telefon, old.deleted, old.created_at, old.updated_at);
  SELECT id INTO id_2  FROM persDeleted ;
   IF id_2 = :old.id  THEN   
   IF :old.deleted = 1 THEN 
    raise_application_error ( - 20111 , 'Acest tuplu a fost deja sters '); 
    ELSE 
    IF :old.deleted = 0  THEN 
     UPDATE pers SET deleted = 1 WHERE id = :old.id;
     END IF;
     END IF;
     END IF;

END;
/


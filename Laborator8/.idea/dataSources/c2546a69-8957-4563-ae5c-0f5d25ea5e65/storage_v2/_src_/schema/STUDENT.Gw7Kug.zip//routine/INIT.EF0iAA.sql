create function init return myType is
    ret myType := myType();
begin
    for i in 1..10 loop
        ret.extend;
        ret(i) := i;
    end loop;
    return ret;
end;
/


create PROCEDURE p
AS 
BEGIN 

DELETE FROM pers WHERE id = 2;
DELETE FROM pers WHERE id = 2;
END p ;
/


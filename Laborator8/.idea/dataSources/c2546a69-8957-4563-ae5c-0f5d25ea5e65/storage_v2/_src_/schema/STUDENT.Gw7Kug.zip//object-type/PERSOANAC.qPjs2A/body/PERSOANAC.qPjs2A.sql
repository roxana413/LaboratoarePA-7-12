create TYPE BODY persoanaC AS
    CONSTRUCTOR FUNCTION persoanaC (
        cnp VARCHAR2
    ) RETURN SELF AS RESULT AS
    BEGIN
        self.cnp := cnp;
        self.nume:= 'Perosoana';
        self.email := 'persoana@yahoo.com';
        self.telefon := '0764563723';
        return;
    END;

   CONSTRUCTOR FUNCTION persoanaC( nume VARCHAR2,
   cnp VARCHAR2,
   telefon VARCHAR2,
   email VARCHAR2)  RETURN SELF AS RESULT AS
   BEGIN
   self.cnp := cnp;
        self.nume:= nume;
        self.email := email;
        self.telefon :=telefon;
        return;
   END;

    MEMBER PROCEDURE save IS
    BEGIN
       INSERT INTO PERSOANA VALUES (self.nume, self.cnp, self.email, self.telefon);
    END save;

END;
/


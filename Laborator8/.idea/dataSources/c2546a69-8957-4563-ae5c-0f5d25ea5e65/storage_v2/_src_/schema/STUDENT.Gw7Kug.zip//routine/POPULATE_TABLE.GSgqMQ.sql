create PROCEDURE populate_table  AS 
  f_file UTL_FILE.FILE_TYPE;
  v_telefon VARCHAR2(30);
  v_string      VARCHAR2(30);
  v_id NUMBER;
  cnt INTEGER;


  BEGIN --END

  f_file := utl_file.fopen('STUDENT','info.txt','r');
  v_id := 0;



  IF UTL_FILE.IS_OPEN(f_file) then LOOP --testat
  BEGIN 
  UTL_FILE.GET_LINE(f_file, v_string);
  v_telefon := regexp_substr(v_string,'[^,]+',1,4);


  select count(*) INTO cnt 
  from persoane
  where  telefon = v_telefon  ;

  if ( cnt = 2 )
  then
   raise_application_error ( - 20111 , 'O persoana cu acelasi nr de telefon deja exista '); 
else
  insert INTO persoane VALUES ( v_id, regexp_substr(v_string,'[^,]+',1,1),
  regexp_substr(v_string,'[^,]+',1,2), regexp_substr(v_string,'[^,]+',1,3), 
  regexp_substr(v_string,'[^,]+',1,4));

  v_id := v_id +1;


  end if;
  END;
  END loop;--
  END IF;--primul if
  END; --procedure 
/


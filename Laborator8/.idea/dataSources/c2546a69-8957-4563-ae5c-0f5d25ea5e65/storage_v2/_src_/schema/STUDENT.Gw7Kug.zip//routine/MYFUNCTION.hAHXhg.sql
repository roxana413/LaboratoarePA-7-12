create function myFunction(p_parametru myType, toBeFound int) return int is
begin
    for i in p_parametru.first..p_parametru.last loop
        if (p_parametru(i) = toBeFound) then
            return 1;
        end if;
    end loop;
    return 0;
end myFunction;
/


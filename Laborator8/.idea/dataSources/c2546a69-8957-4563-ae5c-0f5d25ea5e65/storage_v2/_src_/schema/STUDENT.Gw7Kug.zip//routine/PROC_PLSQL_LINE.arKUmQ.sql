create PROCEDURE proc_plsql_line
    IS
    BEGIN
       RAISE VALUE_ERROR;
    EXCEPTION
       WHEN VALUE_ERROR
       THEN
          DBMS_OUTPUT.put_line ( 'Error raised in: '|| $$plsql_unit ||' at line ' || $$plsql_line || ' - '||sqlerrm);
   END;
/


create PROCEDURE add_new_genre ( genre_id IN NUMBER, genre_name IN VARCHAR2)
   IS 
   counter INTEGER;
   cont INTEGER;
   id_exists EXCEPTION;
   genre_name_exists EXCEPTION;
   BEGIN 
       SELECT COUNT (*)  INTO cont FROM GENRES;
       IF genre_id <= cont THEN
           RAISE id_exists;
        ELSE 

              SELECT COUNT (*) INTO counter  FROM GENRES WHERE name_of_genres= genre_name ;

              IF counter > 0 
              THEN
                RAISE genre_name_exists;
               ELSE 
                INSERT INTO genres VALUES(genre_id, genre_name); 
              END IF ;
        END IF;

        EXCEPTION 
        WHEN  id_exists THEN 
        raise_application_error ( -20003, 'Ati incercat sa inserati un id care deja exista');
        WHEN   genre_name_exists THEN 
        raise_application_error ( -20003, 'Ati incercat sa inserati un gen care deja exista');
        WHEN OTHERS THEN
        raise_application_error (-20003,'An error has occurred inserting an genre.');
        -- raise_application_error(-20001,'An error was encountered - '||SQLCODE||' -ERROR- '||SQLERRM);
    END;
/


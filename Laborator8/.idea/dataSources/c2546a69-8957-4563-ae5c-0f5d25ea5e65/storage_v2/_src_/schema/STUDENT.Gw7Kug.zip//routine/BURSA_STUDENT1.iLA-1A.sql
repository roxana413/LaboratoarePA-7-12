create FUNCTION bursa_student1 (
pi_id_student IN studenti.id%type )
 RETURN VARCHAR2 
 AS 
   bursa_student INTEGER;
   mesaj VARCHAR2(32767);
   counter INTEGER;
 BEGIN 
   SELECT bursa 
   INTO bursa_student FROM STUDENTI WHERE pi_id_student=id AND bursa IS NOT NULL;
   mesaj := 'Bursa studentului cu ID-ul ' || pi_id_student || ' este ' || bursa_student || '.' ;
   RETURN mesaj;

EXCEPTION 
  WHEN no_data_found THEN 
      SELECT COUNT(*) INTO counter FROM studenti WHERE id=pi_id_student;
      IF counter = 0 THEN 
      raise_application_error ( -20001,'Studentul cu ID-ul ' || pi_id_student || ' nu exista in baza de date.');
      DBMS_OUTPUT.put_line ( 'Error raised: '|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || ' - '||sqlerrm);
      DBMS_OUTPUT.put_line ( 'Error raised in: '|| $$plsql_unit ||' at line ' || $$plsql_line || ' - '||sqlerrm);
      END IF;
      SELECT bursa INTO counter FROM studenti WHERE id=pi_id_student;
      IF counter IS null THEN 
      raise_application_error ( -20002,'Studentul cu ID-ul ' || pi_id_student || ' nu are bursa.');
      DBMS_OUTPUT.put_line ( 'Error raised: '|| DBMS_UTILITY.FORMAT_ERROR_BACKTRACE || ' - '||sqlerrm);
      DBMS_OUTPUT.put_line ( 'Error raised in: '|| $$plsql_unit ||' at line ' || $$plsql_line || ' - '||sqlerrm);
      END IF;

END bursa_student1;
/


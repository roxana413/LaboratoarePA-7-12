create TYPE persoanaC AS OBJECT (
   nume VARCHAR2(30),
   cnp VARCHAR2(30),
   telefon VARCHAR2(30),
   email VARCHAR2 (30),
   member    procedure save,
   CONSTRUCTOR FUNCTION persoanaC ( cnp VARCHAR2 ) RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION persoanaC( nume VARCHAR2,
   cnp VARCHAR2,
   telefon VARCHAR2,
   email VARCHAR2)  RETURN SELF AS RESULT );
/


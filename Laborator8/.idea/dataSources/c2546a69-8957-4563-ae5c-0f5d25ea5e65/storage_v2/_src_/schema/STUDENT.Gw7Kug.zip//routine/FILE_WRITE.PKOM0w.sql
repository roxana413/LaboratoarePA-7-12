create PROCEDURE  file_write (f_name in VARCHAR2, nr in INTEGER)
  AS 
  file_out UTL_FILE.FILE_TYPE;
  v_linie persoane%rowtype;

  BEGIN 

  file_out := UTL_FILE.FOPEN('STUDENT', f_name, 'w');

  FOR counter in 0..nr 
  LOOP 
  SELECT * INTO v_linie FROM persoane WHERE id = counter; 

  UTL_FILE.PUTF(file_out, 'id:' || v_linie.id ||  ' nume: ' || v_linie.nume || 
  ' prenume : ' || v_linie.prenume || ' email: ' || v_linie.email || ' nr_telefon: ' 
  || v_linie.telefon );

  UTL_FILE.PUT_LINE(file_out,' ');

  END LOOP;
  UTL_FILE.FCLOSE(file_out);

  END;
/


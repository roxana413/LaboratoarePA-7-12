create FUNCTION bursa_student (
pi_id_student IN studenti.id%type )
 RETURN VARCHAR2 
 AS 
   bursa_student INTEGER;
   mesaj VARCHAR2(32767);
   counter INTEGER;
   student_inexistent EXCEPTION; 
   PRAGMA EXCEPTION_INIT(student_inexistent, -20001);
   student_fara_bursa EXCEPTION; 
   PRAGMA EXCEPTION_INIT(student_fara_bursa, -20002);

 BEGIN 
   SELECT COUNT(*) INTO counter FROM STUDENTI WHERE pi_id_student=id;
   IF counter = 0 THEN 
    raise student_inexistent; 
   ELSE 
      SELECT bursa 
        INTO bursa_student FROM STUDENTI WHERE pi_id_student=id;
     IF bursa_student IS null THEN 
      raise student_fara_bursa;  
      END IF; 
    END IF ; 

     SELECT bursa 
     INTO bursa_student FROM STUDENTI WHERE pi_id_student=id ;
   mesaj := 'Bursa studentului cu ID-ul ' || pi_id_student || ' este ' || bursa_student || '.' ;
     RETURN mesaj;

EXCEPTION 
  WHEN student_inexistent THEN 
      raise_application_error ( -20001,'Studentul cu ID-ul ' || pi_id_student || ' nu exista in baza de date.');
  WHEN student_fara_bursa THEN 
      raise_application_error ( -20002,'Studentul cu ID-ul ' || pi_id_student || ' nu are bursa.');


END bursa_student;
/

